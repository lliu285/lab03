package lab03;

public class Lab3Main 
{

    public static void main(String[] args) 
    {
    	Dollar[] currencyArray = new Dollar[20];
        currencyArray[0] = new Dollar(57.12);
        currencyArray[1] = new Dollar(23.44);
        currencyArray[2] = new Dollar(87.43);
        currencyArray[3] = new Dollar(68.99);
        currencyArray[4] = new Dollar(111.22);
        currencyArray[5] = new Dollar(44.55);
        currencyArray[6] = new Dollar(77.77);
        currencyArray[7] = new Dollar(18.36);
        currencyArray[8] = new Dollar(543.21);
        currencyArray[9] = new Dollar(20.21);
        currencyArray[10] = new Dollar(345.67);
        currencyArray[11] = new Dollar(36.18);
        currencyArray[12] = new Dollar(48.48);
        currencyArray[13] = new Dollar(101.00);
        currencyArray[14] = new Dollar(11.00);
        currencyArray[15] = new Dollar(21.00);
        currencyArray[16] = new Dollar(51.00);
        currencyArray[17] = new Dollar(1.00);
        currencyArray[18] = new Dollar(251.00);
        currencyArray[19] = new Dollar(151.00);
       
        SinglyLinkedList list = new SinglyLinkedList();
        
        for (int i = 6; i >= 0; i--) {
        	list.addCurrency(currencyArray[i], list.getCount());
        	//System.out.println(list.printList());
        }
        
        System.out.println(list.printList());
        
        System.out.println("$87.43 has an index of: " + list.findCurrency(new Dollar(87.43)));
        System.out.println("$44.56 has an index of: " + list.findCurrency(new Dollar(44.56)));
        
        
    }

}
